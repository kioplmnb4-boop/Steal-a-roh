# 🏆 Steal a Roh

잠든 녀석들의 큰 손을 훔쳐 기지로 도망치는 3D 게임 (Three.js).

## 실행 방법
1. `index.html`을 더블클릭해서 브라우저(크롬/엣지/사파리)로 엽니다.
2. **인터넷 연결이 필요해요.** Three.js(r128)와 PeerJS(멀티플레이)를 CDN에서 불러옵니다.
   - 완전 오프라인으로 쓰려면 `three.min.js`를 받아 `js/` 폴더에 넣고,
     `index.html`의 three 주소를 `js/three.min.js`로 바꾸세요.
3. 이미지·음악은 `js/assets/*.js` 안에 들어 있어서 별도 서버 없이 파일을 그냥 열어도 동작합니다.

## 폴더 구조
```
steal-a-roh/
├─ server.js           멀티플레이 중계 서버 (게임 파일도 같이 보여줌)
├─ package.json        서버 실행 설정 (node server.js)
├─ index.html          화면(HUD, 시작 화면, 백업 창) + 스크립트 로드
├─ css/style.css       스타일
├─ js/
│  ├─ game.js          게임 본체 (이동·훔치기·상점·던전/보스·백업 슬롯)
│  └─ assets/          게임이 실제로 읽는 이미지·음악 (base64 데이터)
│     ├─ images.js     NPC 18종
│     ├─ hand.js       큰 손 + 투사체 이미지
│     ├─ skins.js      스킨 이미지
│     ├─ boss.js       보스 이미지
│     ├─ pface.js      플레이어 얼굴
│     └─ bgm.js, deposit.js, caught.js, cry.js   음악/효과음
├─ assets/             위 데이터의 원본 파일 (확인·교체 참고용)
│  ├─ npc/, skins/, audio/ , *.webp, npcs.json ...
└─ README.md
```
> `assets/`의 파일을 바꿔도 게임에는 바로 반영되지 않아요. 게임은 `js/assets/*.js`를 읽습니다.

## 👥 친구랑 같이 하기 (멀티플레이)

### 학교에서 하려면: 중계 서버 방식 (추천)
모두가 서버 하나에 https로 접속해서 같이 해요. 학교 와이파이처럼 컴퓨터끼리 직접 연결이 막힌 곳에서도 잘 되는 방식이에요.
`server.js`가 **게임 화면도 같이 보여줘서**, 서버 주소 하나만 열면 끝이에요.

**① 서버 올리기 (무료 · 처음 한 번만, 10분 정도)**
1. https://github.com 에 가입 → 오른쪽 위 **+ → New repository** → 이름 `steal-a-roh` → **Create repository**
2. **uploading an existing file** 링크 클릭 → `steal-a-roh` 폴더 **안의 파일·폴더 전부**를 끌어다 놓기
   (`server.js`, `package.json`, `index.html`, `css`, `js`, `assets` … 이 바로 보여야 해요) → **Commit changes**
3. https://render.com 에 **GitHub로 가입/로그인** → **+ New → Web Service** → 방금 만든 `steal-a-roh` 저장소 선택
4. 설정:
   - Language: **Node**
   - Build Command: `npm install` (그대로 둬도 돼요)
   - Start Command: `node server.js`
   - Instance Type: **Free**
5. **Deploy Web Service** → 몇 분 뒤 위쪽에 `https://steal-a-roh-xxxx.onrender.com` 같은 주소가 생겨요. 이게 게임 주소예요!

**② 같이 하기**
1. 방장과 친구 모두 그 주소를 열어요.
2. 방장: 이름 입력 → **🏠 방 만들기** → 왼쪽 아래에 나온 **방 코드 5자리**를 친구에게 알려주기
3. 친구: 코드 입력 → **🚪 참가**
4. 왼쪽 아래 표시에 **🛰️서버**라고 나오면 서버 방식으로 연결된 거예요.

**알아둘 점**
- 무료 서버는 **15분 동안 아무도 안 쓰면 잠들어요.** 다음에 주소를 열면 깨어나는 데 **1분쯤** 걸려요(로딩 화면이 보여요). 노는 동안에는 안 잠들어요.
- 학교 인터넷 필터가 `onrender.com` 주소를 막으면 안 될 수 있어요. 그럴 땐 선생님께 허용을 부탁하거나 다른 무료 서버(Railway, Fly.io 등)에 같은 방법으로 올려 보세요.
- 집 컴퓨터에서 테스트: Node.js를 설치하고 이 폴더에서 `node server.js` → 브라우저에서 http://localhost:8080
- 게임은 Netlify에, 서버는 따로 올렸다면 `js/game.js`의 `SERVER_URL`에 `'wss://서버주소/ws'`를 적으세요.

### 서버 없이 하기 (PeerJS 직접 연결)
Netlify처럼 서버가 없는 곳에 올렸거나 서버에 연결이 안 되면, 자동으로 **직접 연결(🔗직접)**을 시도해요.
집 와이파이에서는 대부분 되지만, 학교·회사 망에서는 막힐 수 있어요.

### 공통
- 최대 8명이 같은 맵에서 해요. 서로의 캐릭터와 이름이 보여요.
- **받침대·NPC는 공유**: 친구가 먼저 훔친 큰 손은 못 훔쳐요. NPC는 훔친 사람을 쫓아가요.
- **던전·보스도 같이**: 같이 싸우고, 보스를 잡으면 안에 있던 사람이 모두 각자 보상을 받아요.
- 돈·속도·러닝머신·수집품·스킨은 **각자 자기 브라우저에 저장**돼요. (학교 컴퓨터는 껐다 켜면 지워질 수 있으니 💾 백업도 활용하세요)
- 방장 컴퓨터가 게임을 계산해요. **방장은 탭을 닫지 마세요.** 방장이 나가면 친구들은 혼자 모드로 이어서 해요.

## 조작
- PC: WASD 이동 · Space 점프 · E 훔치기/베기 · M BGM · 마우스 드래그 시점 · 휠 줌
- 모바일: 왼쪽 가상 조이스틱 · 오른쪽 점프/훔치기 버튼

## 주요 기능
- 훔치기 → 도망 → 입금 → 러닝머신 구매로 성장, 오프라인 수입(최대 8시간, 25%)
- 던전/보스: 190×190 대형 아레나, 보스 3단계, 바닥이 찢어져 생긴 **구멍에 빠지면 즉사**
- 💾 **백업 슬롯 3개** (시작 화면 또는 게임 중 왼쪽 💾 버튼) — 브라우저 localStorage에 저장

## 자주 바꾸는 곳 (js/game.js)
| 무엇 | 찾을 이름 |
|---|---|
| 러닝머신 가격 증가율 | `PRICE_GROWTH` |
| 보스 체력/공격/구멍 패턴 | `spawnBoss`, `updateBoss`, `ripPlan` |
| 아레나 크기 | `TS`, `TN` (칸 크기 × 칸 수) |
| 보스 보상 | `bossDie` 안의 `rw` |
| 오프라인 수입 비율 | `load()` 안의 `0.25` |
